package HW6;

public enum WeaponType {
        SWORD, BOW, STAFF
    }


